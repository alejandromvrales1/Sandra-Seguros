# Sitio de Sandra Pereda — Guía de publicación

Este sitio está construido con **Jekyll**, que GitHub Pages soporta de forma
nativa y gratuita. No necesitas pagar hosting ni "compilar" nada: subes los
archivos y GitHub genera el sitio automáticamente.

## 1. Crear el repositorio en GitHub

1. Crea una cuenta en https://github.com si no tienes una.
2. Crea un repositorio nuevo, público, con el nombre que quieras (ej. `sandra-seguros`).
3. Sube todos los archivos de esta carpeta al repositorio. Puedes hacerlo de dos formas:
   - **Más fácil**: en la página del repo, "Add file" → "Upload files", arrastra todo.
   - **Con git** (si lo tienes instalado):
     ```bash
     cd sandra-seguros
     git init
     git add .
     git commit -m "Primera versión del sitio"
     git branch -M main
     git remote add origin https://github.com/TU-USUARIO/sandra-seguros.git
     git push -u origin main
     ```

## 2. Activar GitHub Pages

1. En el repositorio, ve a **Settings → Pages**.
2. En "Build and deployment", elige **Source: Deploy from a branch**.
3. Selecciona la rama `main` y la carpeta `/ (root)`.
4. Guarda. En unos minutos tu sitio estará en `https://TU-USUARIO.github.io/sandra-seguros`.

## 3. Conectar tu dominio (el que ya tienes comprado)

No necesitas comprar nada de nuevo ni mover el dominio. Solo cambias hacia
dónde apunta.

**A. Crea el archivo CNAME**
En la raíz del proyecto, crea un archivo llamado exactamente `CNAME`
(sin extensión) con una sola línea dentro, tu dominio sin `https://`:

```
www.tudominio.com
```

**B. Configura los DNS donde compraste el dominio**

Si compraste el dominio en Hostinger (aunque dejes de usar su hosting, el
dominio puede seguir registrado ahí), entra a su panel → DNS / Zona DNS, y
agrega:

| Tipo  | Nombre | Valor                  |
|-------|--------|------------------------|
| A     | @      | 185.199.108.153        |
| A     | @      | 185.199.109.153        |
| A     | @      | 185.199.110.153        |
| A     | @      | 185.199.111.153        |
| CNAME | www    | TU-USUARIO.github.io   |

Elimina cualquier registro A o CNAME viejo que apunte a Hostinger para `@` y `www`.

**C. Activa el dominio en GitHub**
En **Settings → Pages → Custom domain**, escribe tu dominio y guarda.
Activa "Enforce HTTPS" (puede tardar unas horas en estar disponible).

> La propagación de DNS puede tardar entre 30 minutos y 24 horas.

**D. Actualiza `_config.yml`**
Cambia la línea `url:` por tu dominio real, por ejemplo:
```
url: "https://www.tudominio.com"
```
Y en `robots.txt`, cambia la URL del sitemap por la misma.

## 4. Agregar el logo y la foto reales

Cuando tengas el logo y la foto:
- Logo: sustituye `assets/images/logo.svg` por tu archivo (puede ser `.png` o `.svg`;
  si cambias la extensión, actualiza la referencia en `_includes/header.html`).
- Foto de Sandra: sustituye los recuadros "Foto de Sandra (pendiente de subir)"
  en `index.html` y `sobre-mi.html` por una etiqueta `<img>` apuntando a tu
  archivo en `assets/images/`.

## 5. Publicar nuevas entradas del blog

Para subir un artículo nuevo, copia uno de los archivos en `_posts/` y:
1. Nómbralo con el formato `AAAA-MM-DD-titulo-del-articulo.md`.
2. Cambia el `title`, `category` (autos / salud / vida / ahorro) y `excerpt` arriba.
3. Escribe el contenido en Markdown debajo.
4. Sube el archivo al repositorio (o haz `git push`). En 1-2 minutos aparece publicado.

## 6. Aparecer en los primeros resultados de Google (SEO)

El sitio ya está optimizado técnicamente (metadatos, sitemap automático,
datos estructurados de negocio local, velocidad por ser un sitio estático).
Pero el posicionamiento real depende de estos pasos, que sí tienes que hacer tú:

1. **Google Search Console** (gratis): https://search.google.com/search-console
   Agrega tu dominio, verifica la propiedad, y envía la URL de tu sitemap:
   `https://www.tudominio.com/sitemap.xml`

2. **Google Business Profile** (gratis, clave para SEO local):
   https://www.google.com/business/ — crea el perfil de "Sandra Pereda,
   Agente de Seguros" con dirección/zona, teléfono y horario. Esto es lo que
   más ayuda a aparecer cuando alguien busca "agente de seguros en [tu ciudad]".

3. **Reseñas**: pide a clientes satisfechos que dejen reseña en el perfil de Google.
   El SEO local depende muchísimo de esto.

4. **Actualiza el blog seguido**: cada artículo nuevo es una oportunidad de
   aparecer para una búsqueda distinta (ej. "seguro de auto deducible Jalisco").
   Publicar con regularidad importa más que la cantidad de una sola vez.

5. **Backlinks locales**: que cámaras de comercio, directorios locales o
   negocios aliados en Jalisco enlacen a tu sitio también ayuda.

## 7. Probarlo en tu computadora antes de subir (opcional)

Si tienes Ruby instalado:
```bash
bundle install
bundle exec jekyll serve
```
Y abre `http://localhost:4000` en tu navegador.
